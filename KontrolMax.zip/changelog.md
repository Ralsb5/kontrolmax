# Log de cambios
Log de cambios del sistema Inventio Max

## v9.0 > 23/MAR/2020
- Soporte completo para PHP 7
- Reportes Word y Excel a PHP 7
- Manejo de 3 Precios por Producto
- Agregar clientes en Ventas y Cotizaciones
- Se agrego la opcion para depositos/ajustes
- Se actualizo el modulo de cortes de caja ahora por usuario
- Corte de caja especial para el administrador
- Se agrego la vista de dashboard2
- Se agrego a la grafica morris la opcion de gastos y depositos
- Al vender si se ingresa un codigo de barra se agrega el producto automaticamente al carrito
- Se eliminaron las tablas XX y YY

## v8.3
- Se corrigio las opciones de credito
- Se agrego la opcion para el iva sumado
- Se agrego la grafica de dona en el dashboard
- Se agregaron las ventas y compras en la grafica de lineas morris
- En ventas a credito se puede ver el estado pendiente de los pagos