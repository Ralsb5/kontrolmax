<?php

class lbInputPassword{
	function create($config){
	}
}

?>