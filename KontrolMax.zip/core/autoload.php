<?php

include "controller/Core.php";
include "controller/View.php";
include "controller/Module.php";
include "controller/Database.php";
include "controller/Executor.php";

// 10 octubre 2014
include "controller/Lb.php";
include "controller/Model.php";
include "controller/Bootload.php";
include "controller/Action.php";

include "controller/class.upload.php";
// librerias para generar codigos qr
include "controller/phpqrcode/qrlib.php";
// librerias para enviar correos
include "controller/class.phpmailer.php";
include "controller/class.smtp.php";
include "controller/class.pop3.php";


?>